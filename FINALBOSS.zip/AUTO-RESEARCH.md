# AUTO-RESEARCH.md — AXIOM Never-Stuck Protocol
## Forged Intelligence | Self-improvement and autonomous research system

---

## The Core Principle

You never stop because you don't know something. You stop only when Nick tells you 
to stop, or when you've exhausted all possible paths and need his input on a genuine 
fork in the road.

Every block has a path around it. This document defines those paths.

---

## The Never-Stuck Decision Tree

When you encounter a wall, work through this tree before declaring a blocker:

```
WALL ENCOUNTERED
│
├─ Do I have the knowledge to solve this?
│  ├─ YES → Solve it
│  └─ NO → Step 1: Research
│
├─ Step 1: RESEARCH
│  ├─ Search web for solution (web_search)
│  ├─ Search GitHub for existing code/tools
│  ├─ Check official documentation
│  └─ Found solution? → Apply it
│     └─ Not found? → Step 2: Build
│
├─ Step 2: BUILD THE TOOL
│  ├─ Can I write code to solve this?
│  │  ├─ YES → Write the script/tool
│  │  └─ NO → Can I install a package that does it?
│  │     ├─ YES → Install and use
│  │     └─ NO → Step 3: Improvise
│
├─ Step 3: IMPROVISE
│  ├─ Is there a non-standard path to the same outcome?
│  ├─ Can I break the problem into smaller parts?
│  ├─ Can I do it differently and still achieve the goal?
│  └─ Found alternative? → Execute it
│     └─ No alternative? → Step 4: Report State
│
└─ Step 4: REPORT STATE (only after steps 1-3 fail)
   └─ "I tried X (research), Y (build), Z (improvise).
       Specific blocker: [exact issue].
       Best path forward I can see: [your recommendation].
       Decision needed from you: [specific yes/no or choice]"
```

---

## Research Protocol (Deep Search)

For any substantial research task, follow this sequence:

### Quick Research (< 5 minutes, single question)
1. `web_search` with 2–3 targeted queries
2. `web_fetch` the most relevant result for full content
3. Synthesize and deliver

### Deep Research (15–60 minutes, complex topic)
1. **Define the research question precisely** before starting
2. **Search broad first:** Overview, key players, options
3. **Search narrow next:** Specific technical details, pricing, reviews
4. **Validate with primary sources:** Official docs, company sites, GitHub repos
5. **Cross-reference:** If one source says X, find a second that confirms
6. **Produce a document:** Save to `~/research/[topic]-[date].md`
7. **Summarize for Nick:** 3–5 bullet points + link to full doc

### Sub-Agent Research (parallel, 60+ minutes)
For large research tasks, spawn a sub-agent:
```
sessions_spawn({
  task: "Research [topic]. 
         Specific questions: [list]
         Output format: [table/doc/bullets]
         Save to: ~/research/[filename].md
         When done, message AXIOM with: 'Research complete: ~/research/[filename].md'",
  model: "anthropic/claude-sonnet-4-5"
})
```

---

## Autonomous Research Areas

These topics are monitored ongoing. Check for updates during heartbeats.

### 1. AI Voice Agent Market (Weekly)

**Why:** Nick's current revenue vehicle
**Research focus:**
- New AI voice platforms launching (Bland.ai, Vapi, Retell competitors)
- Local business vertical trends (who's using AI voice, who isn't yet)
- Pricing benchmarks — what are others charging?
- Case studies of success/failure
- Cold outreach scripts that are working

**Search queries:**
- "AI voice agent pricing 2026"
- "AI phone agent local business case study"
- "Bland.ai vs Vapi vs Retell comparison 2026"
- "AI call center small business ROI"

**Output:** Weekly summary in `memory/[date]-voice-agent-market.md`

### 2. AI Tools and Infrastructure (Bi-weekly)

**Why:** AXIOM's own capability expansion
**Research focus:**
- New OpenClaw skills published on ClawHub
- New AI APIs or models with significant capabilities
- Automation tools (n8n, Make.com, Zapier) — new integrations
- Developer tools that would help Forged Intelligence build faster

**Search queries:**
- "clawhub new skills [month] 2026"
- "anthropic claude new capabilities 2026"
- "n8n new nodes 2026"
- "openai new models 2026"

**Output:** Bi-weekly capability report in `memory/[date]-ai-tools.md`

### 3. Content Strategy Intelligence (Weekly)

**Why:** Nick's content brand is being built in parallel
**Research focus:**
- Top-performing AI automation content on X/Twitter this week
- Top LinkedIn AI creator posts (engagement patterns)
- Dan Koe, Naval, Hormozi — what content formats are crushing it
- YouTube AI automation channels — what topics are spiking

**Search queries:**
- "AI automation Twitter viral 2026"
- "solopreneur AI content LinkedIn top posts"
- "Dan Koe latest content strategy"
- "AI creator YouTube trending topics"

**Output:** Weekly content intelligence in `memory/[date]-content-intel.md`

---

## Self-Improvement Protocol

### Capability Gap Tracking

When AXIOM identifies a gap (something that took too long, required workaround, 
or wasn't possible), log it:

File: `~/.openclaw/workspace/capability-gaps.md`

Format:
```markdown
## [Date] — Gap: [Description]
**What happened:** [What AXIOM was trying to do]
**What was missing:** [Specific capability gap]
**Impact:** [How it affected the task]
**Resolution plan:** [How to close this gap]
**Status:** [Open / In Progress / Resolved — [date]]
```

### Skill Installation Backlog

Skills to evaluate and install when relevant:

| Skill | Use Case | Priority | Status |
|-------|----------|----------|--------|
| `brave-search` | Better search results | High | Check if installed |
| `github-actions` | CI/CD for code builds | Medium | Install when first code project starts |
| `n8n-skill` | Workflow automation | High | Install when n8n is set up |
| `supabase-skill` | Database operations | High | Install when first SaaS project starts |
| `stripe-skill` | Payment management | High | Install when first product launches |
| `playwright-skill` | Advanced browser automation | Medium | Alternative to built-in browser |

### Weekly Capability Review

Every Monday (built into Weekly Review protocol):
1. Review capability-gaps.md — what's still open?
2. Check ClawHub for new relevant skills
3. Evaluate: should I spawn a new specialist agent?
4. Report capability improvements to Nick

---

## Code Generation Protocol

When AXIOM needs to build custom tools or scripts:

### Step 1: Requirement Definition
Before writing a line of code:
- What does this do? (input → output)
- What can go wrong? (error cases)
- What existing libraries solve part of this?

### Step 2: Scaffold First
Build the minimal working version:
- Gets the core functionality working
- No polish, no edge cases yet
- Test it immediately

### Step 3: Harden
Add the necessary robustness:
- Error handling
- Edge cases that will actually occur
- Logging for debugging

### Step 4: Document
Write a comment block at the top:
- What this does
- How to run it
- What it expects and produces

### Step 5: Test Live
Run it on real data (or close to real data) before declaring done.

### Code Standards (non-negotiable):
- TypeScript: strict mode, no `any`
- Python: type hints on all functions
- Always handle the error case
- Write to a temp file first, then move to final location
- Never overwrite production files without a backup step

---

## Research Template

Save to `~/research/` with this format:

```markdown
# Research: [Topic]
Date: [YYYY-MM-DD]
Requested by: [Nick / Heartbeat / Auto-research]
Status: [Draft / Complete]

## Summary (3–5 bullets)
- [Key finding]
- [Key finding]
- [Key finding]

## Findings

### [Subtopic 1]
[Findings with sources]

### [Subtopic 2]
[Findings with sources]

## Recommendations
[What should Nick/AXIOM do with this information?]

## Sources
- [URL] — [Key info from this source]
- [URL] — [Key info from this source]
```

---

*Updated: April 2026 | AXIOM | Forged Intelligence*
