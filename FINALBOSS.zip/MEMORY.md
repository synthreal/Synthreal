# MEMORY.md — AXIOM Long-Term Memory
## Forged Intelligence | Persistent across all sessions

---

## How to Use This File

This is your permanent memory. It survives session resets, reboots, and context 
compression. Write here when something is important enough to persist indefinitely.

**Update this file when:**
- Nick explicitly says "remember this" or gives a permanent preference
- You complete a task and the outcome should inform future work
- A system or workflow becomes operational
- Revenue, client, or project status changes
- You discover something critical about how to work with Nick

**Do not write here:**
- Daily task logs (those go in `memory/YYYY-MM-DD.md`)
- Temporary context that won't matter in 2 weeks
- Raw research output (save to `/projects/` or `~/research/`)

---

## Core Identity

- **Agent:** AXIOM
- **System:** Forged Intelligence OpenClaw — Local Windows 11, WSL2
- **Online since:** [Update on BOOTSTRAP completion]
- **Owner:** Nick | Minneapolis, MN
- **Mission:** Build Forged Intelligence to $100K/month MRR

---

## Revenue Tracking

### Current Stage: $0 → $3K/month

**MRR as of last update:** $0 (pre-revenue, building)
**Target:** $3,000/month
**Primary vehicle:** AI voice agent services to local businesses
**Path:** 2–4 clients at $500–$2,000/month retainer

**Revenue Events:**
- [Date, event, amount — will fill as milestones hit]

---

## Active Projects

### [PROJECT 001] AI Voice Agent Service Launch

**Status:** Building
**Goal:** First 2 paying clients at $1,000–$1,500/month each = $2K–$3K MRR
**Next actions:**
- Define target niche (dentists? real estate? contractors?)
- Build the offer document
- Build outreach system
- Build the demo agent
- Land first client

**Key decisions made:**
- [will fill as decisions are made]

**Tools being used:**
- [will fill as tools are selected]

---

## Nick's Permanent Preferences

### Communication
- Always get to the point immediately — no preamble
- Give recommendations first, then reasoning
- Build it, don't describe how to build it
- Direct push-back on weak ideas is welcome and expected

### Work
- 3–4 focused hours daily maximum
- Family time is non-negotiable
- System-first thinking — every output should tend toward autonomy
- Current milestone focus: $3K MRR — evaluate everything against this

### Technical
- Windows 11 host, WSL2 for Linux operations
- Stack: Next.js 14, TypeScript, Tailwind, Supabase, Vercel
- Design: dark luxury (#0A0A0F background, #6366F1 accent)
- Code: TypeScript strict mode, named exports, Zod validation, semantic HTML

### Content
- Voice: Naval density + Ogilvy persuasion
- Platforms: X/Twitter, LinkedIn, YouTube
- Framework: "One Pillar → Seven Channels"

---

## Operational Systems

### Memory system
- Daily logs: `~/.openclaw/workspace/memory/YYYY-MM-DD.md`
- Long-term: this file (MEMORY.md)
- Projects: `~/.openclaw/workspace/projects/[name]/`

### Cron jobs running
- 7:00 AM daily — Morning brief
- 12:00 AM daily — Midnight reflection
- 8:00 AM Monday — Weekly review

### Skills installed
- [Will fill as skills are installed in BOOTSTRAP]

---

## Agent Team Registry

### Active Agents

| Agent | Role | Created | Status |
|-------|------|---------|--------|
| AXIOM | Primary orchestrator, meta-builder | April 2026 | Active |

*Specialists will be added here on Day 3+ as AXIOM builds the team*

### Planned Specialists (Day 3+)

| Codename | Domain | Priority |
|----------|--------|----------|
| ECHO | Content creation, social publishing | High |
| CODEX | Full-stack code generation | High |
| FORGE | Revenue architecture, offer creation | Medium |
| SCOUT | Research, competitive intelligence | Medium |

---

## Key Learnings

### What Works for Nick
- [Will fill from observation]

### What Doesn't Work
- [Will fill from observation]

### Proven Technical Approaches
- [Will fill as AXIOM builds and discovers patterns]

---

## Important Contacts and Accounts

*Note: No passwords or API keys here — those are in ~/.openclaw/.env*

| Account | Purpose | Notes |
|---------|---------|-------|
| Anthropic API | AXIOM's primary model | Key in .env |
| Telegram Bot | Nick ↔ AXIOM interface | Token in .env |
| Brave Search | Web research | Key in .env |

---

## Session History Summary

### Recent Notable Events
- [April 2026] AXIOM went online — fresh local Windows 11 WSL2 install

---

*Last updated by AXIOM: [session timestamp]*
*Next scheduled update: Midnight reflection cron*
