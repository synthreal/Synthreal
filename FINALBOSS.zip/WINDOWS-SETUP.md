# AXIOM — Complete Windows 11 Local Setup Guide
# Forged Intelligence | April 2026
# i9 + RX 6800 XT + 32GB RAM — Built for this.

---

## Why WSL2 (Not Native Windows)

WSL2 is the definitive install path for OpenClaw on Windows. Native PowerShell 
has two known bugs as of 2026: orphaned processes blocking port 18789 on restarts, 
and the /restart slash command failing (it requires systemd, which only WSL2 has).
WSL2 gives you the full Linux runtime while staying entirely on your machine.

Your i9 + 32GB RAM: allocate 16GB to WSL2 and keep 16GB for Windows. 
Your 6800 XT with ~16GB VRAM can run local Ollama models alongside cloud API 
when you're ready. That's a $0/month option for lighter tasks.

Total setup time: 45–60 minutes. Do it once. It runs forever.

---

## PHASE 1 — Windows Prerequisites

### Step 1: Enable WSL2

Open PowerShell as Administrator:

```powershell
# Enable WSL
wsl --install

# If already have WSL1, upgrade to WSL2
wsl --set-default-version 2

# Install Ubuntu 24.04 LTS (the stable, recommended distro)
wsl --install -d Ubuntu-24.04

# Verify
wsl --list --verbose
```

Reboot when prompted.

### Step 2: Configure WSL2 RAM Allocation

Create this file at `C:\Users\<YourUsername>\.wslconfig`:

```ini
[wsl2]
memory=16GB
processors=8
swap=4GB
localhostForwarding=true
```

Then restart WSL:
```powershell
wsl --shutdown
wsl
```

### Step 3: Install Windows Terminal (if not already)

```powershell
winget install Microsoft.WindowsTerminal
```

Set Ubuntu as the default profile in Windows Terminal settings.

### Step 4: Get Your API Keys Ready

Before proceeding, have these ready (you'll need them during setup):

- **Anthropic API Key** — platform.anthropic.com → API Keys
- **Telegram Bot Token** — Message @BotFather on Telegram → /newbot → follow prompts
- **Telegram Chat ID** — Message @userinfobot on Telegram → it replies with your ID  
- **Brave Search API Key** (optional but recommended) — api.search.brave.com
  Free tier: 2,000 searches/month. Paid: $3/1,000 after that.
- **OpenClaw Gateway Token** — generate any strong random string (32+ chars)
  Run in terminal: `openssl rand -hex 32` or use any password manager.

---

## PHASE 2 — WSL2 Ubuntu Setup

Open Ubuntu in Windows Terminal and run everything below.

### Step 5: Update Ubuntu and Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install essentials
sudo apt install -y git curl ca-certificates build-essential

# Set timezone to Minneapolis/Chicago
sudo timedatectl set-timezone America/Chicago

# Verify timezone
date
```

### Step 6: Install Node.js 22 (via nvm — the right way)

```bash
# Install nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash

# Reload shell
source ~/.bashrc

# Install Node.js 22 LTS
nvm install 22
nvm use 22
nvm alias default 22

# Verify
node --version   # Should show v22.x.x
npm --version    # Should show 10.x.x
```

### Step 7: Performance Optimization (Node.js compile cache)

```bash
# Add to ~/.bashrc for faster CLI startup
cat >> ~/.bashrc << 'EOF'

# OpenClaw performance
export NODE_COMPILE_CACHE=/var/tmp/openclaw-compile-cache
mkdir -p /var/tmp/openclaw-compile-cache
export OPENCLAW_NO_RESPAWN=1
EOF

source ~/.bashrc
```

### Step 8: Install OpenClaw Globally

```bash
# Install OpenClaw (always install latest)
npm install -g openclaw@latest

# Verify
openclaw --version
```

---

## PHASE 3 — OpenClaw Configuration (Before Onboarding)

Run this BEFORE the onboarding wizard. We're deploying a pre-built professional 
config instead of answering 20 wizard questions.

### Step 9: Create the Config Directory and Environment File

```bash
# Create OpenClaw config directory
mkdir -p ~/.openclaw

# Create your .env file (NEVER commit this to git)
cat > ~/.openclaw/.env << 'EOF'
ANTHROPIC_API_KEY=sk-ant-YOUR_KEY_HERE
TELEGRAM_BOT_TOKEN=YOUR_BOT_TOKEN_HERE
TELEGRAM_YOUR_CHAT_ID=YOUR_CHAT_ID_HERE
BRAVE_API_KEY=YOUR_BRAVE_KEY_HERE
OPENCLAW_GATEWAY_TOKEN=YOUR_GENERATED_TOKEN_HERE
EOF

# Lock down permissions (only your user can read)
chmod 600 ~/.openclaw/.env

echo "Environment file created. Edit it with: nano ~/.openclaw/.env"
```

### Step 10: Deploy All Workspace Files

```bash
# Create workspace directory
mkdir -p ~/.openclaw/workspace/memory
mkdir -p ~/.openclaw/workspace/skills

# Copy all AXIOM files from this package
# (Run this from the AXIOM package directory you downloaded)
cp workspace/* ~/.openclaw/workspace/

echo "Workspace files deployed"
```

### Step 11: Deploy the openclaw.json Config

```bash
# Copy main config
cp openclaw.json ~/.openclaw/openclaw.json

# Open and fill in your values (or they'll be loaded from .env)
nano ~/.openclaw/openclaw.json
```

### Step 12: Source Environment Variables

```bash
# Add env file loading to bashrc so OpenClaw always has your keys
cat >> ~/.bashrc << 'EOF'

# Load OpenClaw secrets
if [ -f ~/.openclaw/.env ]; then
  set -a
  source ~/.openclaw/.env
  set +a
fi
EOF

source ~/.bashrc
```

---

## PHASE 4 — OpenClaw Onboarding

### Step 13: Run Onboarding with Daemon Installation

```bash
openclaw onboard --install-daemon
```

**In the wizard, choose:**
- Security warning: **Accept** (read it, then continue)
- Flow: **Manual** (not quickstart — we have our own config)
- Auth provider: **Anthropic API Key** → paste your key
- Gateway port: **18789** (default, keep it)
- Bind: **Loopback** (localhost only — critical for security)
- Install as daemon: **Yes**
- Channel setup: **Skip** (we configure Telegram via config file)
- Skills: **Skip** (we install specific ones manually)
- Hatch: **Skip** (we'll do BOOTSTRAP manually)

### Step 14: Verify the Install

```bash
# Check gateway status
openclaw gateway status

# Run health check
openclaw health

# Run doctor (fix any flagged issues)
openclaw doctor
openclaw doctor --fix

# Run security audit
openclaw security audit
```

---

## PHASE 5 — Telegram Channel Setup

### Step 15: Connect Telegram

```bash
# Add your Telegram bot token to the config
# (already done if you edited openclaw.json correctly)

# Test the connection
openclaw channels status --probe
```

On Telegram, send a message to your bot. You should get a response.

If no response:
```bash
openclaw logs --follow
# Look for any channel errors
```

---

## PHASE 6 — Install Core Skills

### Step 16: Install Day 1 Skills

Run these one at a time. Each installs into `~/.openclaw/workspace/skills/`:

```bash
# Web research (critical — AXIOM uses this constantly)
npx clawhub@latest install web-search

# Git and GitHub integration (for code projects)
npx clawhub@latest install git-github

# Docker management (for running containers)
npx clawhub@latest install docker-essentials

# Verify skills installed
openclaw skills list
```

---

## PHASE 7 — Auto-Start (PM2)

### Step 17: Install PM2 for Reliable Background Operation

```bash
# Install PM2
npm install -g pm2

# NOTE: WSL2 with systemd (already enabled) is the primary daemon
# PM2 is a backup layer for extra reliability

# Check systemd service status
sudo systemctl status openclaw

# Enable auto-start on WSL boot
sudo systemctl enable openclaw
```

### Step 18: WSL2 Auto-Start on Windows Boot

Create this file on the Windows side to auto-launch WSL2 when Windows starts.

In PowerShell:
```powershell
# Create a startup script
$script = @"
wsl -u root service openclaw start
"@
$scriptPath = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\start-openclaw.ps1"
$script | Out-File -FilePath $scriptPath -Encoding UTF8

# Create a shortcut to run it silently
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\OpenClaw.lnk")
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-WindowStyle Hidden -File `"$scriptPath`""
$Shortcut.Save()

Write-Host "OpenClaw will now auto-start with Windows"
```

---

## PHASE 8 — First Boot: Talk to AXIOM

### Step 19: The BOOTSTRAP Command

Open Telegram. Message your bot EXACTLY this (copy-paste it):

```
Hey, let's get you set up. Read BOOTSTRAP.md and walk me through it.
```

**Do not send any other message first.** The BOOTSTRAP.md will:
1. Confirm AXIOM's identity and name
2. Ask you about yourself to fill USER.md
3. Set up the initial memory structure
4. Confirm all tools are working
5. Run a capability test

This takes 5–10 minutes. Do it before asking AXIOM anything else.

---

## PHASE 9 — Verification Checklist

After first boot, verify all systems:

```bash
# Gateway running
openclaw gateway status

# Logs clean (no errors)
openclaw logs --limit 50

# Session active
openclaw status --all

# Skills loaded
openclaw skills list --eligible

# Heartbeat test
openclaw system heartbeat last
```

On Telegram, send:
```
/status
```

You should get a full system status report.

---

## Maintenance Commands (Cheat Sheet)

```bash
# Daily
openclaw gateway status          # Quick health check
openclaw logs --follow           # Watch live logs
openclaw sessions --active 60    # Active sessions

# Updates (run weekly)
npm update -g openclaw
npx clawhub@latest sync --all    # Update all skills

# Troubleshooting
openclaw doctor --deep --yes     # Full diagnostic + auto-fix
openclaw security audit          # Security scan
openclaw gateway restart         # Restart if stuck

# Emergency reset (nuclear option)
openclaw sessions cleanup --enforce
openclaw gateway --force
```

---

## Security Rules (Non-Negotiable)

1. Gateway is bound to loopback ONLY — never expose port 18789 externally
2. Auth token is always set — zero unauthenticated access
3. `.env` file has `chmod 600` — only you can read it
4. `requireMention: true` in any group chats — AXIOM only speaks when called
5. Never use Tailscale Funnel — use Tailscale Serve for remote access
6. Add `.env` to `.gitignore` if you ever put workspace in git

---

*Setup complete. AXIOM is online.*
