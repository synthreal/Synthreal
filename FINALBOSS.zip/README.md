# AXIOM — Forged Intelligence Primary Agent
## Day 1 Complete Build | Windows 11 Local | April 2026

---

## What This Is

AXIOM is your fully autonomous, self-improving AI operator built on OpenClaw. 
He runs 24/7 on your local Windows 11 machine, contacts you via Telegram, and 
works while you sleep.

**Not a chatbot. An operator.**

Every file here is production-ready. Not a template. Not a placeholder.
Deploy it, run BOOTSTRAP, and go.

---

## File Inventory

```
AXIOM/
├── README.md                    ← This file (start here)
├── WINDOWS-SETUP.md             ← Complete installation guide
├── openclaw.json                ← Master config (copy to ~/.openclaw/)
├── .env.template                ← Environment variables (copy + fill in)
└── workspace/                   ← Copy entire folder to ~/.openclaw/workspace/
    ├── SOUL.md                  ← AXIOM's identity [AUTO-INJECTED]
    ├── AGENTS.md                ← Operating rules [AUTO-INJECTED]
    ├── TOOLS.md                 ← Tool harness [AUTO-INJECTED]
    ├── USER.md                  ← Nick's profile
    ├── MEMORY.md                ← Long-term persistent memory
    ├── HEARTBEAT.md             ← 4-hour autonomous loop protocol
    ├── BOOTSTRAP.md             ← First-boot initialization (run ONCE)
    ├── AUTO-RESEARCH.md         ← Never-stuck self-improvement protocol
    └── memory/                  ← Daily logs directory (auto-created)
```

---

## Quick Start (5 Steps)

### 1. Install Prerequisites (Windows PowerShell as Admin)
```powershell
# Enable WSL2
wsl --install -d Ubuntu-24.04
# Reboot when prompted
```

### 2. Set Up WSL2 Ubuntu (run everything below in Ubuntu terminal)
```bash
# Update and install Node.js 22
sudo apt update && sudo apt upgrade -y
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 22 && nvm use 22

# Install OpenClaw
npm install -g openclaw@latest

# Verify
openclaw --version
```

### 3. Deploy Config Files
```bash
# Create directories
mkdir -p ~/.openclaw/workspace/memory
mkdir -p ~/.openclaw/workspace/skills

# Copy config (from this package)
cp openclaw.json ~/.openclaw/
cp workspace/* ~/.openclaw/workspace/
cp .env.template ~/.openclaw/.env
chmod 600 ~/.openclaw/.env

# Fill in your API keys
nano ~/.openclaw/.env
```

### 4. Run Onboarding
```bash
# Source your env vars
source ~/.openclaw/.env

# Run onboarding
openclaw onboard --install-daemon
# Choose: Manual flow, Anthropic API, loopback, install daemon, skip channels/skills
```

### 5. Install Skills + First Boot
```bash
# Install core skills
npx clawhub@latest install web-search
npx clawhub@latest install git-github
npx clawhub@latest install docker-essentials
```

Then go to Telegram and send your bot this EXACT message (first message only):
```
Hey, let's get you set up. Read BOOTSTRAP.md and walk me through it.
```

---

## What Happens Next

### Day 1–2: Solo Operation
AXIOM works with you directly. He learns your preferences, runs your first tasks,
and builds the memory foundation. You focus on what to build. He builds it.

### Day 3+: Team Building  
AXIOM begins identifying gaps in his own capabilities and building specialist agents:
- ECHO — content creation and publishing
- CODEX — full-stack development
- FORGE — revenue architecture
- SCOUT — research and intelligence

He does this without being asked. You'll get a message: "I've built [agent]. Here's what they do."

### Week 2+: Autonomous Revenue
AXIOM is running the morning brief, midnight reflection, and heartbeats.
He's researching the voice agent market, tracking competitors, building your 
outreach systems — while you're focused on your 3–4 hour daily window.

---

## The Autonomous Schedule

| Time | Event | What Happens |
|------|-------|-------------|
| 7:00 AM daily | Morning Brief | AXIOM messages you with priorities |
| Every 4 hours | Heartbeat | Silent check, logs to memory |
| 12:00 AM daily | Midnight Reflection | Memory consolidation, no message |
| Monday 8:00 AM | Weekly Review | Full week summary + priorities |

---

## Architecture (How It Works)

```
Nick (Telegram)
      │
      ▼
AXIOM (OpenClaw gateway — localhost:18789)
      │
      ├── SOUL.md → Identity and philosophy
      ├── AGENTS.md → Operating rules (auto-injected)
      ├── TOOLS.md → Tool permissions (auto-injected)
      ├── MEMORY.md → Long-term brain
      ├── HEARTBEAT.md → Autonomous loop
      └── AUTO-RESEARCH.md → Self-improvement
      │
      ├── Bash/Terminal → Your Windows 11 machine (via WSL2)
      ├── Browser → Chrome automation
      ├── Web Search → Brave API
      ├── File System → Full read/write
      └── Sub-Agents → Specialist workers (Day 3+)
```

---

## Security Summary

- Gateway bound to localhost ONLY (127.0.0.1:18789)
- Auth token required for every connection
- `.env` file has 600 permissions (you only)
- Telegram DM allowlist — only your chat ID
- Group chats require @mention
- Destructive actions require Nick's confirmation
- External content treated as potentially hostile

---

## Model Costs (Realistic)

| Usage Level | Cost/Month | Who This Is |
|-------------|-----------|-------------|
| Light (chat, small tasks) | $5–15 | Just starting |
| Medium (coding, research daily) | $20–50 | Active building |
| Heavy (multiple agents, heavy automation) | $50–150 | Full empire mode |

**Pro tip:** Use Claude Pro OAuth instead of direct API key to bundle into subscription.

---

## When Something Breaks

```bash
# The fix sequence
openclaw doctor --deep --yes    # Auto-diagnose and fix
openclaw gateway restart        # Restart if stuck
openclaw logs --follow          # Watch what's happening
openclaw status --all           # Full system status

# Nuclear option (wipes session, keeps memory)
openclaw sessions cleanup --enforce
openclaw gateway --force
```

---

## Built On Proven Patterns From:

- OpenClaw official documentation (docs.openclaw.ai)
- mergisi/awesome-openclaw-agents — 162 production templates
- amanaiproduct/openclaw-setup — battle-tested security hardening
- raulvidis/openclaw-multi-agent-kit — 10-agent production template
- Lenny's Newsletter complete guide — real-world usage patterns
- Windows 11 WSL2 setup guides — multiple sources cross-referenced

---

*AXIOM | Forged Intelligence | Minneapolis, MN | April 2026*
*Built to run 24/7. Built to compound. Built to win.*
